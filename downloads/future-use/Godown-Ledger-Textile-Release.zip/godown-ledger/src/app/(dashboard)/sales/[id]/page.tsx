import { db } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import { ChevronLeft, Pencil, RotateCcw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExpiryBadge } from "@/components/inventory/expiry-badge";
import { PrintButton } from "@/components/sales/print-button";
import { InvoiceReverseControls } from "@/components/sales/invoice-reverse-controls";
import { WhatsAppShareButton } from "@/components/sales/whatsapp-share-button";
import { BrandingFooter } from "@/components/branding-footer";
import { formatCurrency, formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";

interface Props {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: Props) {
  const { id } = await params;
  const session = await getServerSession(authOptions);
  if (!session?.user) return { title: "Invoice" };
  const inv = await db.saleInvoice.findFirst({
    where: { id, companyId: session.user.companyId },
    select: { invoiceNumber: true },
  });
  return { title: inv?.invoiceNumber ?? "Invoice" };
}

export default async function InvoiceDetailPage({ params }: Props) {
  const { id } = await params;

  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  const companyId = (session.user as any).companyId as string;

  const [invoice, company] = await Promise.all([
    db.saleInvoice.findFirst({
      where: { id, companyId },
      include: {
        customer: { select: { name: true, phone: true, address: true } },
        returns: { where: { status: "POSTED" }, select: { totalAmount: true } },
        user: { select: { name: true, role: true } },
        items: {
          include: {
            product: { select: { name: true, unit: true } },
            batch: { select: { batchNumber: true, expiryDate: true } },
          },
          orderBy: { id: "asc" },
        },
      },
    }),
    db.company.findFirst({
      where: { id: companyId },
      select: {
        name: true,
        logoUrl: true,
        phone: true,
        address: true,
        email: true,
        taxNumber: true,
        strnNumber: true,
      },
    }),
  ]);

  if (!invoice) notFound();

  const net = parseFloat(invoice.netAmount.toString());
  const paid = parseFloat(invoice.paidAmount.toString());
  const returned = invoice.returns.reduce(
    (sum, r) => sum + Number(r.totalAmount),
    0,
  );
  const balance = net - paid - (invoice.customerId ? returned : 0);
  const isPaid = balance <= 0.001;
  const isPartial = !isPaid && paid > 0.001;
  // A cash memo (walk-in, no customer on account) is settled in full at the
  // counter — payment mode and the paid/balance figures are the point of the
  // document. A credit invoice tracks that separately via the customer
  // ledger, so those fields would just be noise on the printed copy.
  const isCashMemo = !invoice.customerId;

  return (
    <div className="max-w-4xl mx-auto space-y-6 print:max-w-none print:space-y-0 print:p-8">
      {invoice.directDeal && (
        <div className="rounded border border-blue-200 bg-blue-50 p-4">
          <strong>Direct mill-to-buyer deal</strong>
          <p>{invoice.notes}</p>
          <p>No godown stock was received or deducted.</p>
        </div>
      )}
      {returned > 0 && (
        <p className="rounded border border-amber-200 bg-amber-50 p-3 text-sm">
          Returns against this bill: {formatCurrency(returned)}.{" "}
          {invoice.customerId
            ? "Credited to the buyer’s account."
            : "Refunded in cash."}
        </p>
      )}
      {/* Screen header — hidden when printing */}
      <div className="flex items-start justify-between print:hidden">
        <div className="flex items-center gap-3">
          <Link
            href="/sales"
            className="text-slate-400 hover:text-slate-600 transition-colors"
          >
            <ChevronLeft className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-xl font-bold text-slate-900 font-mono">
              {invoice.invoiceNumber}
            </h1>
            <p className="text-sm text-slate-500">
              {formatDate(invoice.invoiceDate)}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {invoice.status === "POSTED" && !invoice.directDeal && (
            <>
              <Link href={`/sales/${invoice.id}/edit`}>
                <Button variant="outline" size="sm">
                  <Pencil className="h-4 w-4" />
                  Edit
                </Button>
              </Link>
              {["OWNER", "ACCOUNTANT"].includes(session.user.role) && (
                <Link href={`/sales/returns/new?invoiceId=${invoice.id}`}>
                  <Button variant="outline" size="sm">
                    <RotateCcw className="h-4 w-4" />
                    Return
                  </Button>
                </Link>
              )}
            </>
          )}
          <WhatsAppShareButton
            invoiceNumber={invoice.invoiceNumber}
            invoiceDate={formatDate(invoice.invoiceDate)}
            netAmount={invoice.netAmount.toString()}
            paidAmount={invoice.paidAmount.toString()}
            customerName={
              invoice.customer?.name ?? invoice.walkInCustomerName ?? undefined
            }
            customerPhone={invoice.customer?.phone ?? undefined}
            companyName={company?.name ?? ""}
            isPaid={isPaid}
          />
          <PrintButton />
          {invoice.status === "POSTED" &&
            !invoice.directDeal &&
            ["OWNER", "ACCOUNTANT"].includes(session.user.role) && (
              <InvoiceReverseControls invoiceId={invoice.id} />
            )}
          {invoice.status === "REVERSED" ? (
            <Badge variant="danger">Reversed</Badge>
          ) : isPaid ? (
            <Badge variant="success">Paid</Badge>
          ) : isPartial ? (
            <Badge variant="warning">Partial</Badge>
          ) : (
            <Badge variant="danger">Unpaid</Badge>
          )}
        </div>
      </div>

      {invoice.status === "REVERSED" && (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 print:hidden">
          <p className="text-sm font-medium text-red-800">
            This invoice was reversed
            {invoice.reversedAt ? ` on ${formatDate(invoice.reversedAt)}` : ""}.
          </p>
          {invoice.reversalReason && (
            <p className="text-sm text-red-700 mt-0.5">
              Reason: {invoice.reversalReason}
            </p>
          )}
        </div>
      )}

      {/* Print header — company branding (only visible when printing) */}
      <div className="hidden print:block print:mb-6">
        <div className="flex justify-between items-center pb-4 border-b-2 border-slate-800">
          {/* Left: Company logo + name */}
          <div className="flex items-center gap-4">
            {company?.logoUrl && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={company.logoUrl}
                alt={company.name}
                className="h-16 w-auto object-contain"
              />
            )}
            <div>
              <p className="text-2xl font-bold text-slate-900">
                {company?.name ?? "Company"}
              </p>
              {company?.phone && (
                <p className="text-xs text-slate-500 mt-0.5">{company.phone}</p>
              )}
              {company?.email && (
                <p className="text-xs text-slate-500">{company.email}</p>
              )}
              {company?.address && (
                <p className="text-xs text-slate-500">{company.address}</p>
              )}
              {company?.taxNumber && (
                <p className="text-xs text-slate-500">
                  NTN: {company.taxNumber}
                </p>
              )}
              {company?.strnNumber && (
                <p className="text-xs text-slate-500">
                  STRN: {company.strnNumber}
                </p>
              )}
            </div>
          </div>
          {/* Right: Invoice info */}
          <div className="text-right">
            <p className="text-xs font-bold tracking-widest text-slate-500 uppercase">
              {isCashMemo ? "Cash Memo" : "Sale Invoice"}
            </p>
            <p className="text-2xl font-mono font-bold text-slate-900 mt-0.5">
              {invoice.invoiceNumber}
            </p>
            <p className="text-sm text-slate-600 mt-1">
              Date: {formatDate(invoice.invoiceDate)}
            </p>
            <p
              className={`text-sm font-bold mt-1 ${isPaid ? "text-green-600" : isPartial ? "text-yellow-600" : "text-red-600"}`}
            >
              Status: {isPaid ? "PAID ✓" : isPartial ? "PARTIAL" : "UNPAID"}
            </p>
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden print:border-none print:rounded-none">
        {/* Invoice meta */}
        <div
          className={`px-6 py-4 border-b border-slate-200 grid grid-cols-2 md:grid-cols-3 ${isCashMemo ? "" : "print:grid-cols-2"} gap-4`}
        >
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">
              Customer
            </p>
            <p className="mt-1 text-sm font-semibold text-slate-900">
              {invoice.customer?.name ?? invoice.walkInCustomerName ?? (
                <span className="italic text-slate-400">Walk-in</span>
              )}
            </p>
            {invoice.customer?.phone && (
              <p className="text-xs text-slate-500">{invoice.customer.phone}</p>
            )}
            {invoice.customer?.address && (
              <p className="text-xs text-slate-500">
                {invoice.customer.address}
              </p>
            )}
          </div>
          <div className={isCashMemo ? "" : "print:hidden"}>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">
              Payment Mode
            </p>
            <p className="mt-1 text-sm text-slate-900 capitalize">
              {invoice.paymentMode.toLowerCase().replace("_", " ")}
            </p>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">
              Prepared By
            </p>
            <p className="mt-1 text-sm text-slate-900">
              {invoice.user?.name ?? "—"}
            </p>
            {invoice.dueDate && (
              <div className="print:hidden">
                <p className="text-xs font-medium text-slate-500 uppercase tracking-wider mt-2">
                  Due Date
                </p>
                <p className="text-sm text-slate-900">
                  {formatDate(invoice.dueDate)}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Items table — the Disc%/Tax% columns only appear when at least one
            line actually uses them, so a plain invoice (the common case)
            prints as simply as possible: Product, Qty, Rate, Total. */}
        {(() => {
          const showDiscountColumn = invoice.items.some(
            (item) => parseFloat(item.discount.toString()) > 0,
          );
          const showTaxColumn = invoice.items.some(
            (item) => parseFloat(item.taxRate.toString()) > 0,
          );
          return (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left px-6 py-3 font-medium text-slate-600">
                    #
                  </th>
                  <th className="text-left px-6 py-3 font-medium text-slate-600">
                    Product / Batch
                  </th>
                  <th className="text-right px-6 py-3 font-medium text-slate-600">
                    Qty
                  </th>
                  <th className="text-right px-6 py-3 font-medium text-slate-600">
                    Unit Price
                  </th>
                  {showDiscountColumn && (
                    <th className="text-right px-6 py-3 font-medium text-slate-600">
                      Disc%
                    </th>
                  )}
                  {showTaxColumn && (
                    <th className="text-right px-6 py-3 font-medium text-slate-600">
                      Tax%
                    </th>
                  )}
                  <th className="text-right px-6 py-3 font-medium text-slate-600">
                    Total
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoice.items.map((item, idx) => {
                  const lineTotal = parseFloat(item.totalAmount.toString());
                  return (
                    <tr key={item.id} className="hover:bg-slate-50">
                      <td className="px-6 py-3 text-slate-400">{idx + 1}</td>
                      <td className="px-6 py-3">
                        <p className="font-medium text-slate-900">
                          {item.product.name}
                        </p>
                        <div className="flex items-center gap-1.5 mt-0.5 print:hidden">
                          <span className="font-mono text-[11px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                            {item.batch.batchNumber}
                          </span>
                          <ExpiryBadge
                            expiryDate={
                              item.batch.expiryDate
                                ? item.batch.expiryDate.toISOString()
                                : null
                            }
                          />
                        </div>
                        {item.isBonus && (
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="text-[11px] font-semibold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded">
                              FREE / SCHEME
                            </span>
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-3 text-right text-slate-700">
                        {item.quantity} {item.product.unit}
                      </td>
                      <td className="px-6 py-3 text-right text-slate-700">
                        {formatCurrency(parseFloat(item.salePrice.toString()))}
                      </td>
                      {showDiscountColumn && (
                        <td className="px-6 py-3 text-right text-slate-500">
                          {parseFloat(item.discount.toString()) > 0
                            ? `${parseFloat(item.discount.toString())}%`
                            : "—"}
                        </td>
                      )}
                      {showTaxColumn && (
                        <td className="px-6 py-3 text-right text-slate-500">
                          {parseFloat(item.taxRate.toString()) > 0
                            ? `${parseFloat(item.taxRate.toString())}%`
                            : "—"}
                        </td>
                      )}
                      <td className="px-6 py-3 text-right font-semibold text-slate-900">
                        {item.isBonus ? (
                          <span className="text-amber-700">FREE</span>
                        ) : (
                          formatCurrency(lineTotal)
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          );
        })()}

        {/* Totals */}
        <div className="border-t border-slate-200 px-6 py-4">
          <div className="ml-auto w-64 space-y-2 text-sm">
            <TotalRow
              label="Subtotal"
              value={formatCurrency(parseFloat(invoice.totalAmount.toString()))}
            />
            {parseFloat(invoice.discountAmount.toString()) > 0.001 && (
              <TotalRow
                label="Discount"
                value={`− ${formatCurrency(parseFloat(invoice.discountAmount.toString()))}`}
              />
            )}
            {parseFloat(invoice.taxAmount.toString()) > 0.001 && (
              <TotalRow
                label="Tax"
                value={formatCurrency(parseFloat(invoice.taxAmount.toString()))}
              />
            )}
            <div className="border-t border-slate-200 pt-2">
              <TotalRow label="Net Amount" value={formatCurrency(net)} bold />
            </div>
            <div className={isCashMemo ? "" : "print:hidden"}>
              <TotalRow label="Amount Received" value={formatCurrency(paid)} />
            </div>
            <div
              className={`${isCashMemo ? "" : "print:hidden"} flex justify-between font-bold text-base pt-1 ${
                isPaid
                  ? "text-green-600"
                  : balance < -0.001
                    ? "text-green-600"
                    : "text-red-600"
              }`}
            >
              <span>
                {isPaid
                  ? "Settled ✓"
                  : balance < -0.001
                    ? "Change Due"
                    : "Balance Due"}
              </span>
              <span>
                {Math.abs(balance) < 0.001
                  ? "—"
                  : formatCurrency(Math.abs(balance))}
              </span>
            </div>
          </div>
        </div>

        {/* Notes */}
        {invoice.notes && (
          <div className="border-t border-slate-200 px-6 py-4">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-1">
              Notes
            </p>
            <p className="text-sm text-slate-700">{invoice.notes}</p>
          </div>
        )}
        <BrandingFooter />
      </div>
    </div>
  );
}

function TotalRow({
  label,
  value,
  bold,
}: {
  label: string;
  value: string;
  bold?: boolean;
}) {
  return (
    <div
      className={`flex justify-between ${bold ? "font-semibold text-slate-900" : "text-slate-600"}`}
    >
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}
